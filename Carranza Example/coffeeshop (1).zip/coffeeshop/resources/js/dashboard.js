$(document).ready(function(){
    $('.sidenav').sidenav();
    $('.dropdown-trigger').dropdown();
    $('.materialboxed').materialbox();
    $('.tooltipped').tooltip();
    $('.modal').modal();
});

