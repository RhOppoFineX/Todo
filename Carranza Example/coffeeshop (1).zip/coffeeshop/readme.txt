Esta demo ha sido desarrollada con las siguientes herramientas:
- XAMPP v5.6.15 x32
- Materialize v1.0.0
- jQuery v3.2.1

Inicio del sitio privado:
    localhost/coffeeshop/views/dashboard/

Inicio del sitio público:
    localhost/coffeeshop/views/public/