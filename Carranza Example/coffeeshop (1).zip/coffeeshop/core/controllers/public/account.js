$(document).ready(function()
{
    $('.tabs').tabs();
    $('.tooltipped').tooltip();
})
