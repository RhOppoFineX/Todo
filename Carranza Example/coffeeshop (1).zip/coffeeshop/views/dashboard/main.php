<?php
require_once('../../core/helpers/dashboard.php');
Dashboard::headerTemplate('Bienvenido');
?>
<div class="container">
    <div class="row">
	    <h4 class="center-align blue-text" id="greeting"></h4>
    </div>
</div>
<?php
Dashboard::footerTemplate('main.js');
?>
